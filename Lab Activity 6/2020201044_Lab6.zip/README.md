# Lab Activity – 6

## question 1
* This is the folder that contains `in_besteller.py` that is the solution file to the first question.
* Here, in the question since 100 books are asked, I retrived the information from two pages:
<br>https://www.amazon.in/gp/bestsellers/books/ 
<br>https://www.amazon.in/gp/bestsellers/books/ref=zg_bs_pg_2?ie=UTF8&pg=2
* The output folder has the output csv file called `in_book.csv`

## q2.py
* This contains the solution for finding if the given input string is a panagram or not.

## q3.py
* This contains the solution to finding the sum of lengths of the strings that start with uppercase. 
* The list with the strings starting with uppercase is printed on the next line.
* I have used lambda function for filtering the strings with uppercase.

## q4.py
* This contains the solution for printing the binary numbers that are divisible by 5.
* The binary numbers in the output are seperated by comma.
* Example: <br>
    Input: 0100,0011,1010,1001,1100,1001,101<br>
    Output: 1010,101
