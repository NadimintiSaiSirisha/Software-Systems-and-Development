## SSD Group 13 Project - Colour blindness detection AFrame

### Links:

* PPT Explanation Video Link: https://www.youtube.com/watch?v=y-W7oVCCn4c&feature=youtu.be
* Project Demo Explanation Link: https://www.youtube.com/watch?v=qaSpS7JNqXg&feature=youtu.be
* Link for the Project Demo: https://nadimintisaisirisha.github.io/Colour-blindness-Detection-AFrame/music.html
* Github Repository Link: https://github.com/NadimintiSaiSirisha/Colour-blindness-Detection-AFrame

<br>
Note: Please enable the audio/video for the browser to listen to the music in the project demo.
