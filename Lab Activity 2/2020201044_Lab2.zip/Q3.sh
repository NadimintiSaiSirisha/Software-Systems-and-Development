#!/bin/bash
sed -e 's/./#/5g' "$1"