# Lab 5 Activity: Python Basics

## q1. py
* The two numbers are input in the format of comma seperated numers as: `num1,num2`. 
* The number values are typecasted to float.
* The maximum value of the two numbers is printed as output.
* If both the numbers are saved, then that value is printed.
* Example:<br />
    Input: 100,200<br />
    Output: 200<br />
    Input: 3.9,6.8<br />
    Output: 6.8

## q2. py
* The input character is taken from the user.
* If the input character is vowel, "True" is printed, else "False" is printed.
* Example: <br />
    Input: a<br />
    Output: Ture<br />
    Input: E<br />
    Output: True<br />
    Input: Q<br />
    Output: False <br />

## q3. py
* The input is taken in the form of comma seperated words as : `word1, word2, word3,`
* The output is the list of integers that represents the length of each word.
* Example:<br />
    Input: sai,sirisha,nadiminti<br />
    Output: [3, 7, 9]

## q4. py
* The input string is taken from the user.
* The reverse string is printed as the output. 
* If the input string is blank, then blank will be printed.
* `s = s[::-1]` reverses the string by starting the string from the end and stopping at the beggining of the string.
* Example:<br />
    Input: "I am testing"<br />
    Output: "gnitset ma I"<br />
    Input: (Blank line)<br />
    Output: (Blank line)<br />
