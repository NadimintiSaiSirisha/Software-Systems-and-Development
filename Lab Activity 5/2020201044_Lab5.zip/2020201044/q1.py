a,b = input().split(',')
if(float(a)>float(b)):
    print (a)
else:
    print (b)