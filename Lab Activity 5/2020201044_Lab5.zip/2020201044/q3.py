list=input().split(',')
lengths=[]
for i in list:
    lengths.append(len(i))
print(lengths)