Activity 1:
Assume that the lab activity is being done in the home directory. (pwd: /home/saisirisha)
