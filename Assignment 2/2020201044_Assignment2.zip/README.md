# SSD Assignment 2- HTML/CSS/JavaScript

## index.html
* This is the main html page that is opened when web.iiit.ac.in website is opened.
* It contains references to the .css and .js files.

## images
* I have used four images in this project.

## script.js
* I have written two functions.
* The first function `myFunction` is used for the responsiveness of the navigation bar on resizing. 
* The second function `myFunctionNavigation` is used for the sticky navigation bar. 

## style.css
* This file contains all the css attributes for the html components.

Github pages link : https://nadimintisaisirisha.github.io/saisirishan/