# LAB ACTIVITY 4 

## index.html
* This is the main html page. 
* This page just gives the project topics to be chosen by the student. 

## style.css
In this file, I am just setting the properties for `h1`, `body`, `button`.

## script.js
In this file, I have added the following functions:
* The first two functions are there to show the contents of the dropdown. All the content in the `myDropdown` fed to the dropdown list.
* The third function changes the background image on pressing the `Change the background` button.
* The fourth function generates an alert when '3' is pressed in the input-field given.
* The fifth function makes the text blink. I have also changed the colour of the blinking text to red.

## Image URL
* The background image, named `backgroundSiri.png` has the URL:`https://cdn.glitch.com/529c37ea-ce17-4fa3-b654-74444a83d0d7%2FbackgroundSiri.png?v=1600772723076`.
* Since this is a URL, I am not including the file in the submissions. The background image should be rendered from this URL itself.